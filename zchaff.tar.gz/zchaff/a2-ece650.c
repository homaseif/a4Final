

#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<unistd.h>

#include "SAT.h"
#include "charToInt.h"
#include "extractVertexNumber.h"
#include "createMatrix.h"
#include "minVertexCover.h"
#include "combination.h"
#include "comparison.h"

int main(int argc, char *argv[]){

	int vertex = -1;
	char tmp;
	int flag = 0;
	int **matrix;
	int len;
	char *text;
	char *tmptext;
	int count;
	int freeMatrix = 0;

	while ((tmp = getchar()) != EOF){
  		//Get input, Store in text
  		len = 1000;
  		text = (char *)malloc(len * sizeof(char));
		if(!text){
			fprintf(stderr, "Error: The input size is too large.\n");
			flag = 0;
			vertex = -1;
			continue;
		}
  		count = 0;
  		text[count] = tmp;
  		count++;
		text[count] = '\0';
  		while ((tmp = getchar()) != '\n'){
       			if (count+1 >= len){
          			tmptext = (char *)realloc(text, (len += 100) * sizeof(*tmptext));
				if(!tmptext){
					fprintf(stderr, "Error: The input size is too large.\n");
					flag = 0;
					vertex = -1;
					free(text);
					break;
				}
				text = tmptext;
			}
       			text[count] = tmp;
       			count++;
       			text[count] = '\0';
  		}
		if(!text){
			if(freeMatrix == 1){
				int z;
                		for(z = 0; z < vertex; z++)
                        		free(matrix[z]);
                		free(matrix);
			}
			continue;
		}
  		//V command
  		if(text[0] == 'V'){
  			int vcheck = extractVertexNumber(text, count);
			if(flag == 2 || flag == 3){
				freeMatrix = 0;
				//Free matrix
				int i;
				for(i = 0; i < vertex; i++)
					free(matrix[i]);
				free(matrix);
			}
			if(vcheck < 0){
                                fprintf(stderr, "Error: Set of vertices can not be negative.\n");
                                flag = 0;
                                vertex = -1;
                                free(text);
				continue;
                        }
			vertex = vcheck;
			flag = 1;
			free(text);
  		}

  		//E command
  		else if(text[0] == 'E'){
			if(flag == 0 || flag == 3 || flag == 2){
				fprintf(stderr, "Error: 'V' has to  be entered before 'E'.\n");
				free(text);
				flag = 0;
				vertex = -1;
				continue;
			}
			int err;
			//Matrix allocation
			matrix = (int **)malloc(vertex * sizeof(int*));
        		int i;
        		for (i = 0; i < vertex; i++)
        			matrix[i] = (int *)malloc(vertex * sizeof(int));
			freeMatrix = 1;
			//Create the adjacency matrix
  			err = createMatrix(text, count, vertex, matrix);
			if(err == 1){
				free(text);
				//free matrix
				int j;
                		for(j = 0; j < vertex; j++)
                      			free(matrix[j]);
                		free(matrix);
				freeMatrix = 0;
				flag = 0;
				vertex = -1;
				continue;
			}
			else{
				flag = 2;
				free(text);
  			}

			//Minimum Vertex Cover
			int n = vertex;
			int k = 1;
    			while(k <= n){
				int fd[2];
				int tmp;
				pipe(fd);
				tmp = dup(STDOUT_FILENO);
				dup2(fd[1], STDOUT_FILENO);

				int varNum = n * k;
				int j;
				int m;
				int p;
				int q;
				int edgeNum = 0;
				for(i = 0; i < vertex; i++){
					for(j = 0; j < vertex; j++){
						if(i != j && matrix[i][j] == 1)
							edgeNum++;
					}
				}
				edgeNum = edgeNum / 2;
				int clauseNum = k + n * combination(k,2) + k * combination(n,2) + edgeNum;

				SAT_Manager mgr = SAT_InitManager();
				SAT_SetNumVariables(mgr, varNum);
				int c[clauseNum];

				char index[2];
				int indexNum1;
				int indexNum2;

				for(i = 1; i <= k; i++){
					for(j = 1; j <= n; j++){
						indexNum1 = j + (i-1)*n;
						c[j-1] = (indexNum1 << 1);
					}
					SAT_AddClause(mgr, c, n);
				}
				for(m = 1; m <= n; m++){
					for(p = 1; p <= k; p++){
						for(q = p + 1; q <= k; q++){
							indexNum1 = m + (p-1)*n;
							indexNum2 = m + (q-1)*n;
							c[0] = (indexNum1 << 1) + 1;
							c[1] = (indexNum2 << 1) + 1;
							SAT_AddClause(mgr, c, 2);
						}
					}
				}

				for(m = 1; m <= k; m++){
					for(p = 1; p <= n; p++){
						for(q = p + 1; q <= n ; q++){
							indexNum1 = p + (m-1)*n;
							indexNum2 = q + (m-1)*n;
							c[0] = (indexNum1 << 1) + 1;
							c[1] = (indexNum2 << 1) + 1;
							SAT_AddClause(mgr, c, 2);
						}
					}
				}

				int cnt;
				for(i = 0; i < vertex; i++){
					for(j = i + 1; j < vertex; j++){
						cnt = 0;
						if( matrix[i][j] == 1){
							for(m = 1; m <= k; m++){
								indexNum1 = (i+1) + (m-1)*n;
								indexNum2 = (j+1) + (m-1)*n;
								c[cnt] = (indexNum1 << 1);
								cnt++;
								c[cnt] = (indexNum2 << 1);
								cnt++;
							}
						}
						SAT_AddClause(mgr, c, 2 * k);
					}
				}

				int result = SAT_Solve(mgr);
				dup2(tmp, STDOUT_FILENO);
				if(result == SATISFIABLE){
					int varNum = SAT_NumVariables(mgr);
					int *minVerIndex;
					minVerIndex = (int *)malloc(n * sizeof(int));
					cnt = 0;
					for(i = 1; i <= varNum; i++){
						int varAssign = SAT_GetVarAsgnment(mgr, i);
						if( varAssign == 1){
							if(i > n){
								minVerIndex[cnt] = (i % n) - 1;
								cnt++;
							}
							else{
								minVerIndex[cnt] = i - 1;
								cnt++;
							}
						}
					}
					qsort(minVerIndex, cnt, sizeof(int), comparison);
					for(i = 0; i < cnt; i++){
						printf("%d ", minVerIndex[i]);
						fflush(stdout);
					}
					printf("\n");
					fflush(stdout);
					free(minVerIndex);
					break;
				}
				else
					k++;

    			}


		}

	}


  	if(freeMatrix == 1){
  		int p;
  		for(p = 0; p < vertex; p++)
  			free(matrix[p]);
  		free(matrix);
  	}
  	return 0;
};
