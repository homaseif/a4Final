

int combination(int n, int m){
	if (m > n)
		return 0;
	if (m == 0 || m == n)
		return 1;

	int result = n;
	int i;
	for(i = 2; i <= m; i++) {
		result = result * (n-i+1);
		result = result / i;
	}
	return result;

}
